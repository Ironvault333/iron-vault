import type { Product } from "./supabase";

export type CartItem = {
  id: string;
  name: string;
  slug: string;
  sell_price: number;
  emoji?: string | null;
  quantity: number;
};

const KEY = "ironVaultCart";

export function getCart(): CartItem[] {
  if (typeof window === "undefined") return [];
  return JSON.parse(localStorage.getItem(KEY) || "[]");
}

export function saveCart(items: CartItem[]) {
  if (typeof window === "undefined") return;
  localStorage.setItem(KEY, JSON.stringify(items));
  window.dispatchEvent(new Event("cart-updated"));
}

export function addToCart(product: Product) {
  const items = getCart();
  const existing = items.find((i) => i.id === product.id);
  if (existing) existing.quantity += 1;
  else {
    items.push({
      id: product.id,
      name: product.name,
      slug: product.slug,
      sell_price: Number(product.sell_price),
      emoji: product.emoji,
      quantity: 1,
    });
  }
  saveCart(items);
}
