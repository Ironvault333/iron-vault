import { createClient } from "@supabase/supabase-js";

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || "";
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || "";

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type Product = {
  id: string;
  name: string;
  slug: string;
  category: string;
  description: string;
  image_url: string | null;
  emoji: string | null;
  sell_price: number;
  supplier_cost: number;
  shipping_estimate: string | null;
  supplier_name: string | null;
  supplier_url: string | null;
  supplier_sku: string | null;
  product_score: number | null;
  active: boolean;
  featured: boolean;
  created_at: string;
  updated_at: string;
};
