insert into products (name, slug, category, description, emoji, sell_price, supplier_cost, shipping_estimate, supplier_name, product_score, active, featured)
values
('QuickDry Cleat & Shoe Dryer', 'quickdry-cleat-shoe-dryer', 'Sports Families', 'Forced-air dryer for wet cleats, rain boots, ski boots, and sneakers.', '👟', 49.99, 18.50, '7–12 days', 'Supplier needed', 9.0, true, true),
('Seat Gap Crumb Catcher', 'seat-gap-crumb-catcher', 'Car Inventions', 'Stops fries, crumbs, coins, toys, and phones from falling between car seats.', '🚗', 24.99, 6.80, '6–10 days', 'Supplier needed', 8.7, true, true),
('Glow Boundary Game Kit', 'glow-boundary-game-kit', 'Backyard Games', 'Light-up boundary strips for driveway games, night sports, backyard challenges, and parties.', '💡', 59.99, 19.00, '7–14 days', 'Supplier needed', 8.5, true, true),
('Portable Pickleball Net', 'portable-pickleball-net', 'Sports Products', 'Fast-set driveway pickleball net for families, neighbors, and casual players.', '🏓', 89.99, 34.00, '5–12 days', 'Supplier needed', 8.2, true, false),
('Magnetic Cup Holder Clip', 'magnetic-cup-holder-clip', 'Nice-To-Have', 'Clip/magnet drink holder for bleachers, golf carts, strollers, lawn chairs, gyms, and workbenches.', '🥤', 19.99, 4.50, '6–12 days', 'Supplier needed', 8.0, true, false),
('Color Fire Pack Bundle', 'color-fire-pack-bundle', 'Outdoor Products', 'Color-changing fire packs for camping, fire pits, cabins, parties, and gift bundles.', '🔥', 14.99, 2.75, '5–10 days', 'Supplier needed', 8.8, true, false);
