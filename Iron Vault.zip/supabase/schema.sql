-- Iron Vault Supabase schema

create table if not exists products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text unique not null,
  category text not null default 'Uncategorized',
  description text not null default '',
  image_url text,
  emoji text default '📦',
  sell_price numeric(10,2) not null default 0,
  supplier_cost numeric(10,2) not null default 0,
  shipping_estimate text default 'TBD',
  supplier_name text default 'Supplier needed',
  supplier_url text,
  supplier_sku text,
  product_score numeric(3,1) default 0,
  active boolean default true,
  featured boolean default false,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table if not exists orders (
  id uuid primary key default gen_random_uuid(),
  customer_name text,
  customer_email text,
  customer_phone text,
  status text default 'draft',
  subtotal numeric(10,2) default 0,
  shipping numeric(10,2) default 0,
  tax numeric(10,2) default 0,
  total numeric(10,2) default 0,
  created_at timestamptz default now()
);

create table if not exists order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid references orders(id) on delete cascade,
  product_id uuid references products(id),
  product_name text,
  quantity integer default 1,
  unit_price numeric(10,2) default 0,
  supplier_cost numeric(10,2) default 0
);

create or replace function set_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

drop trigger if exists trg_products_updated_at on products;
create trigger trg_products_updated_at
before update on products
for each row execute function set_updated_at();

alter table products enable row level security;
alter table orders enable row level security;
alter table order_items enable row level security;

-- Public can view active products.
drop policy if exists "Public can view active products" on products;
create policy "Public can view active products"
on products for select
using (active = true);

-- For first prototype only: allow anon read all products.
-- Admin writes should eventually be locked behind Supabase Auth.
drop policy if exists "Prototype admin can manage products" on products;
create policy "Prototype admin can manage products"
on products for all
using (true)
with check (true);

drop policy if exists "Prototype order insert" on orders;
create policy "Prototype order insert"
on orders for insert
with check (true);

drop policy if exists "Prototype order items insert" on order_items;
create policy "Prototype order items insert"
on order_items for insert
with check (true);
