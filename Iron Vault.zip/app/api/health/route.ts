export async function GET() {
  return Response.json({ ok: true, app: "Iron Vault" });
}
