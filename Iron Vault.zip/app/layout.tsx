import "./globals.css";
import Link from "next/link";

export const metadata = {
  title: "Iron Vault",
  description: "Products worth stopping for."
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <header className="header">
          <Link href="/" className="brand">
            <div className="logo">IV</div>
            <div>
              <h1>Iron Vault</h1>
              <p>Products worth stopping for.</p>
            </div>
          </Link>
          <nav className="nav">
            <Link href="/products">Products</Link>
            <Link href="/cart">Cart</Link>
            <Link href="/admin" className="button">Admin</Link>
          </nav>
        </header>
        {children}
      </body>
    </html>
  );
}
