 "use client";

import { useEffect, useState } from "react";
import { supabase, Product } from "@/lib/supabase";
import Link from "next/link";

const blank = {
  name: "",
  slug: "",
  category: "",
  description: "",
  image_url: "",
  emoji: "📦",
  sell_price: 0,
  supplier_cost: 0,
  shipping_estimate: "",
  supplier_name: "Supplier needed",
  supplier_url: "",
  supplier_sku: "",
  product_score: 0,
  active: true,
  featured: false,
};

function slugify(v: string) {
  return v.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
}

function money(n: number) { return "$" + Number(n || 0).toFixed(2); }

export default function AdminPage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [form, setForm] = useState<any>(blank);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [message, setMessage] = useState("");

  async function load() {
    const { data } = await supabase.from("products").select("*").order("created_at", { ascending: false });
    setProducts(data || []);
  }

  useEffect(() => { load(); }, []);

  function updateField(name: string, value: any) {
    setForm((f: any) => {
      const next = { ...f, [name]: value };
      if (name === "name" && !editingId) next.slug = slugify(value);
      return next;
    });
  }

  async function saveProduct() {
    setMessage("");
    const payload = {
      ...form,
      slug: form.slug || slugify(form.name),
      sell_price: Number(form.sell_price || 0),
      supplier_cost: Number(form.supplier_cost || 0),
      product_score: Number(form.product_score || 0),
      image_url: form.image_url || null,
      supplier_url: form.supplier_url || null,
      supplier_sku: form.supplier_sku || null,
    };

    const result = editingId
      ? await supabase.from("products").update(payload).eq("id", editingId)
      : await supabase.from("products").insert(payload);

    if (result.error) setMessage(result.error.message);
    else {
      setMessage("Saved.");
      setForm(blank);
      setEditingId(null);
      await load();
    }
  }

  function edit(p: Product) {
    setEditingId(p.id);
    setForm({ ...p, image_url: p.image_url || "", supplier_url: p.supplier_url || "", supplier_sku: p.supplier_sku || "" });
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  async function remove(id: string) {
    if (!confirm("Delete this product?")) return;
    await supabase.from("products").delete().eq("id", id);
    await load();
  }

  return (
    <div className="adminLayout">
      <div className="panel">
        <h2>{editingId ? "Edit Product" : "Add Product"}</h2>
        <div className="form">
          <label>Name</label>
          <input value={form.name} onChange={(e) => updateField("name", e.target.value)} />
          <label>Slug</label>
          <input value={form.slug} onChange={(e) => updateField("slug", e.target.value)} />
          <label>Category</label>
          <input value={form.category} onChange={(e) => updateField("category", e.target.value)} />
          <label>Description</label>
          <textarea value={form.description} onChange={(e) => updateField("description", e.target.value)} />
          <div className="formGrid">
            <div><label>Sell Price</label><input type="number" step="0.01" value={form.sell_price} onChange={(e) => updateField("sell_price", e.target.value)} /></div>
            <div><label>Supplier Cost</label><input type="number" step="0.01" value={form.supplier_cost} onChange={(e) => updateField("supplier_cost", e.target.value)} /></div>
          </div>
          <div className="formGrid">
            <div><label>Shipping Estimate</label><input value={form.shipping_estimate || ""} onChange={(e) => updateField("shipping_estimate", e.target.value)} /></div>
            <div><label>Product Score</label><input type="number" step="0.1" value={form.product_score || 0} onChange={(e) => updateField("product_score", e.target.value)} /></div>
          </div>
          <label>Supplier Name</label>
          <input value={form.supplier_name || ""} onChange={(e) => updateField("supplier_name", e.target.value)} />
          <label>Supplier URL</label>
          <input value={form.supplier_url || ""} onChange={(e) => updateField("supplier_url", e.target.value)} />
          <label>Supplier SKU</label>
          <input value={form.supplier_sku || ""} onChange={(e) => updateField("supplier_sku", e.target.value)} />
          <div className="formGrid">
            <div><label>Emoji</label><input value={form.emoji || ""} onChange={(e) => updateField("emoji", e.target.value)} /></div>
            <div><label>Image URL</label><input value={form.image_url || ""} onChange={(e) => updateField("image_url", e.target.value)} /></div>
          </div>
          <label><input type="checkbox" checked={!!form.active} onChange={(e) => updateField("active", e.target.checked)} /> Active</label>
          <label><input type="checkbox" checked={!!form.featured} onChange={(e) => updateField("featured", e.target.checked)} /> Featured</label>
          <button onClick={saveProduct}>Save Product</button>
          <button className="secondary" onClick={() => { setForm(blank); setEditingId(null); }}>New Blank</button>
          {message && <p>{message}</p>}
        </div>
      </div>

      <div className="panel">
        <h2>Products</h2>
        <table>
          <thead><tr><th>Product</th><th>Price</th><th>Supplier</th><th>Status</th><th></th></tr></thead>
          <tbody>
            {products.map((p) => (
              <tr key={p.id}>
                <td><b>{p.emoji} {p.name}</b><br /><small>{p.category}</small><br /><Link href={`/products/${p.slug}`}>View</Link></td>
                <td>{money(p.sell_price)}<br /><small>Cost {money(p.supplier_cost)}</small></td>
                <td>{p.supplier_name || "Supplier needed"}<br /><small>{p.shipping_estimate}</small></td>
                <td>{p.active ? "Active" : "Hidden"}</td>
                <td className="rowActions">
                  <button className="secondary" onClick={() => edit(p)}>Edit</button>
                  <button className="danger" onClick={() => remove(p.id)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
