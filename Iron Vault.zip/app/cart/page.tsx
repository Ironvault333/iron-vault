 "use client";

import { useEffect, useState } from "react";
import { CartItem, getCart, saveCart } from "@/lib/cart";

function money(n: number) { return "$" + Number(n || 0).toFixed(2); }

export default function CartPage() {
  const [items, setItems] = useState<CartItem[]>([]);

  useEffect(() => setItems(getCart()), []);

  function update(next: CartItem[]) {
    setItems(next);
    saveCart(next);
  }

  const total = items.reduce((sum, item) => sum + item.sell_price * item.quantity, 0);

  return (
    <section className="section">
      <h2>Your Cart</h2>
      {!items.length ? <p>Your cart is empty.</p> : (
        <div className="panel">
          <table>
            <thead><tr><th>Product</th><th>Qty</th><th>Total</th><th></th></tr></thead>
            <tbody>
              {items.map((item) => (
                <tr key={item.id}>
                  <td><b>{item.emoji} {item.name}</b></td>
                  <td>{item.quantity}</td>
                  <td>{money(item.sell_price * item.quantity)}</td>
                  <td><button className="secondary" onClick={() => update(items.filter(i => i.id !== item.id))}>Remove</button></td>
                </tr>
              ))}
            </tbody>
          </table>
          <h2>Total: {money(total)}</h2>
          <button onClick={() => alert("Next step: connect Stripe checkout and order creation.")}>Demo Checkout</button>
        </div>
      )}
    </section>
  );
}
