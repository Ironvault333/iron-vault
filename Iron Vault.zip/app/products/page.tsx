import ProductCard from "@/components/ProductCard";
import { supabase, Product } from "@/lib/supabase";

async function getProducts(): Promise<Product[]> {
  const { data } = await supabase
    .from("products")
    .select("*")
    .eq("active", true)
    .order("product_score", { ascending: false });

  return data || [];
}

export default async function ProductsPage() {
  const products = await getProducts();

  return (
    <section className="section">
      <h2>All Products</h2>
      <p style={{ color: "var(--muted)", fontSize: 18 }}>Live products from your database.</p>
      <div className="grid">
        {products.map((p) => <ProductCard key={p.id} product={p} />)}
      </div>
    </section>
  );
}
