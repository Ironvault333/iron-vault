 "use client";

import { useEffect, useState } from "react";
import { supabase, Product } from "@/lib/supabase";
import { addToCart } from "@/lib/cart";

export default function ProductDetail({ params }: { params: { slug: string } }) {
  const [product, setProduct] = useState<Product | null>(null);

  useEffect(() => {
    supabase.from("products").select("*").eq("slug", params.slug).single().then(({ data }) => setProduct(data));
  }, [params.slug]);

  if (!product) return <section className="section"><h2>Loading...</h2></section>;

  return (
    <section className="section">
      <div className="hero" style={{ padding: 0 }}>
        <div className="panel">
          <div className="productImage" style={{ height: 420 }}>
            {product.image_url ? <img src={product.image_url} alt={product.name} style={{ width: "100%", height: "100%", objectFit: "cover" }} /> : <span>{product.emoji || "📦"}</span>}
          </div>
        </div>
        <div>
          <span className="kicker">{product.category}</span>
          <h2>{product.name}</h2>
          <p>{product.description}</p>
          <h2 style={{ fontSize: 42 }}>${Number(product.sell_price).toFixed(2)}</h2>
          <p>Estimated shipping: {product.shipping_estimate || "TBD"}</p>
          <button onClick={() => addToCart(product)}>Add to Cart</button>
        </div>
      </div>
    </section>
  );
}
