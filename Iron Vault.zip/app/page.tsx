import ProductCard from "@/components/ProductCard";
import { supabase, Product } from "@/lib/supabase";
import Link from "next/link";

async function getProducts(): Promise<Product[]> {
  const { data } = await supabase
    .from("products")
    .select("*")
    .eq("active", true)
    .order("featured", { ascending: false })
    .order("product_score", { ascending: false })
    .limit(6);

  return data || [];
}

export default async function HomePage() {
  const products = await getProducts();

  return (
    <>
      <section className="hero">
        <div>
          <span className="kicker">Dropship-ready web app</span>
          <h2>Cool products. Strong margins. Built to update live.</h2>
          <p>
            Iron Vault is a real web app structure with a database and admin dashboard.
            Add products in admin and they show on the live storefront.
          </p>
          <Link href="/products" className="button">Shop Products</Link>
        </div>
        <div className="vaultPanel">
          <div className="vaultInner">
            <div>⚙️</div>
            <h2>Open the Vault</h2>
            <p>Sports products, clever inventions, and high-demand nice-to-have finds.</p>
          </div>
        </div>
      </section>

      <div className="notice">
        <b>Build note:</b> This version is ready to connect to Supabase. Once deployed, product edits can update live without downloading a new file.
      </div>

      <section className="section">
        <h2>Featured Products</h2>
        <div className="grid">
          {products.map((p) => <ProductCard key={p.id} product={p} />)}
        </div>
      </section>
    </>
  );
}
