 "use client";

import Link from "next/link";
import type { Product } from "@/lib/supabase";
import { addToCart } from "@/lib/cart";

function money(n: number) {
  return "$" + Number(n || 0).toFixed(2);
}

export default function ProductCard({ product, showCosts = false }: { product: Product; showCosts?: boolean }) {
  const margin = Number(product.sell_price || 0) - Number(product.supplier_cost || 0);

  return (
    <article className="card">
      <Link href={`/products/${product.slug}`}>
        <div className="productImage">
          <span className="score">Score {product.product_score ?? "-"}</span>
          {product.image_url ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={product.image_url} alt={product.name} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
          ) : (
            <span>{product.emoji || "📦"}</span>
          )}
        </div>
      </Link>
      <div className="body">
        <div className="category">{product.category}</div>
        <h3><Link href={`/products/${product.slug}`}>{product.name}</Link></h3>
        <p>{product.description}</p>
        <div className="numbers">
          <div className="num"><small>Sell</small><b>{money(product.sell_price)}</b></div>
          {showCosts && <div className="num"><small>Cost</small><b>{money(product.supplier_cost)}</b></div>}
          {showCosts && <div className="num"><small>Margin</small><b>{money(margin)}</b></div>}
        </div>
        <div className="supplier">
          <span className="badge">{product.shipping_estimate || "TBD"}</span>
          <button onClick={() => addToCart(product)}>Add to Cart</button>
        </div>
      </div>
    </article>
  );
}
